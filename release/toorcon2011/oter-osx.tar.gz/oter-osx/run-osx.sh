#!/bin/bash

java -XstartOnFirstThread -d32 -jar oter-osx.jar 
