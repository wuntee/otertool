#!/bin/bash

java -d32 -jar otertool.jar 
